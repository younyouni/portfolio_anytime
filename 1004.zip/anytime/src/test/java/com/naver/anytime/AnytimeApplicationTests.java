package com.naver.anytime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnytimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
